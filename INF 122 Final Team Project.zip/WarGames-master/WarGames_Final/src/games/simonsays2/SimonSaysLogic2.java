package games.simonsays2;

public class SimonSaysLogic2 {

}
