package bge;

public class Coord {

	private double X;
	private double Y;
	
	public Coord(double x, double y) {
		setX(x);
		setY(y);
	}

	public double getX() {
		return X;
	}

	public void setX(double x) {
		X = x;
	}

	public double getY() {
		return Y;
	}

	public void setY(double y) {
		Y = y;
	}
	
	
}
