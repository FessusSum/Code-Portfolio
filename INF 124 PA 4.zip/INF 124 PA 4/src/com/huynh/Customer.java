package com.huynh;

public class Customer {

	String first_name="";
	String last_name="";
	String email="";
	String phone="";
	String address="";
	String zip="";
	String city="";
	String state="";
	String ship="";
	String card_type="";
	String card_num="";
	int id = 0;
	String order_details="";
	int final_total=0;
	
	public String getFirst_name() {
		return first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public String getEmail() {
		return email;
	}
	public String getPhone() {
		return phone;
	}
	public String getAddress() {
		return address;
	}
	public String getZip() {
		return zip;
	}
	public String getCity() {
		return city;
	}
	public String getState() {
		return state;
	}
	public String getShip() {
		return ship;
	}
	public String getCard_type() {
		return card_type;
	}
	public String getCard_num() {
		return card_num;
	}
	public int getId() {
		return id;
	}
	public String getOrder_details() {
		return order_details;
	}
	public int getFinal_total() {
		return final_total;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public void setState(String state) {
		this.state = state;
	}
	public void setShip(String ship) {
		this.ship = ship;
	}
	public void setCard_type(String card_type) {
		this.card_type = card_type;
	}
	public void setCard_num(String card_num) {
		this.card_num = card_num;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setOrder_details(String order_details) {
		this.order_details = order_details;
	}
	public void setFinal_total(int final_total) {
		this.final_total = final_total;
	}
}
