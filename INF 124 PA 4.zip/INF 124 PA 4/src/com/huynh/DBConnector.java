package com.huynh;

import java.sql.*;


public class DBConnector {
	
	private DBConnector() {
		
	}
	public static Connection getConnection() {

        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {
            return DriverManager.getConnection("jdbc:mysql://" + "sylvester-mccoy-v3.ics.uci.edu" + "/" + "inf124-db-037",
            		"inf124-db-037", "Beanman96!");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return null;
    }


}
