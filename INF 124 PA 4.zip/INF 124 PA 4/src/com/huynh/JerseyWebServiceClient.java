package com.huynh;

import java.io.IOException;
import javax.ws.rs.core.MediaType;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import com.sun.jersey.api.client.*;

public class JerseyWebServiceClient
{
	public String jsonPOST(String webserviceURL, ShoppingCartItem cartItem) {
		try {
			Client client = Client.create();
			WebResource webresource = client.resource(webserviceURL);
			ObjectMapper objectMapper = new ObjectMapper();
			String inputJSON = objectMapper.writeValueAsString(cartItem);
			ClientResponse response = webresource.type("application/json").post(ClientResponse.class, inputJSON);
			if (response.getStatus() != 201) {
				throw new RuntimeException("HTTP Error Code: " + response.getStatus());
			}
			String output = response.getEntity(String.class);
			return output;
		} // end try
		catch (Exception e) {
			e.printStackTrace();
			return "Failed";
		}
	}
	
	public String jsonPOSTcustomer(String webserviceURL, Customer customer) {
		try {
			Client client = Client.create();
			WebResource webresource = client.resource(webserviceURL);
			ObjectMapper objectMapper = new ObjectMapper();
			String inputJSON = objectMapper.writeValueAsString(customer);
			System.out.println(inputJSON);
			System.out.println(webserviceURL);
			ClientResponse response = webresource.type("application/json").post(ClientResponse.class, inputJSON);
			if (response.getStatus() != 200) {
				throw new RuntimeException("HTTP Error Code: " + response.getStatus());
			}
			String output = response.getEntity(String.class);
			return output;
		} // end try
		catch (Exception e) {
			e.printStackTrace();
			return "Failed";
		}
	}
	
	public String jsonGET(String webserviceURL) throws JsonParseException, JsonMappingException, IOException {
		Client client = Client.create();
		WebResource webresource = client.resource(webserviceURL);
		ClientResponse response = webresource.accept("application/json").get(ClientResponse.class);
		if (response.getStatus() != 200) {
			throw new RuntimeException("JerseyWebServiceClient WARNING: error " + response.getStatus());
		}
		String jsonValue = response.getEntity(String.class);
		// ObjectMapper objectMapper = new ObjectMapper(); // For mapping JSON to object
		// List<ShoppingCardItem> shoppingCart = objectMapper.readValue(jsonValue, new TypeReference<List<ShoppingCardItem>>(){ });
		// ShoppingCardItem shoppingCardItem = objectMapper.readValue(jsonValue, ShoppingCardItem.class);
		
		return jsonValue;
	}
	
	public void jsonPUT(String webserviceURL, String jsonValue) {
		Client client = Client.create();
		WebResource webresource = client.resource(webserviceURL);
		ClientResponse response = webresource.type("application/json").put(ClientResponse.class, jsonValue);
		if (response.getStatus() != 200) {
			throw new RuntimeException("JerseyWebServiceClient WARNING: error " + response.getStatus());
		}
	}
	
	public void jsonDEL(String webserviceURL, String jsonValue) {
		Client client = Client.create();
		WebResource webresource = client.resource(webserviceURL);
		ClientResponse response = webresource.type(MediaType.APPLICATION_JSON).delete(ClientResponse.class, jsonValue);
		if (response.getStatus() != 200) {
			throw new RuntimeException("JerseyWebServiceClient WARNING: error " + response.getStatus());
		}
	}
}