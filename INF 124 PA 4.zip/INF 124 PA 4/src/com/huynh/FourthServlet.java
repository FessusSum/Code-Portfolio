package com.huynh;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class FourthServlet
 */
@WebServlet("/FourthServlet")
public class FourthServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FourthServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("deprecation")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("<head>");
		out.println("</head>");
		out.print("<style>");
		out.println(".button{background-color: #008CBA; border: none; color: white; float: right; padding: 15px 32px; font-size: 17px; text-decoration: none; margin: 4px 2px; cursor: pointer;}");
		out.println(".button2{background-color: #008CBA; border: none; color: white; float: left; padding: 15px 32px; font-size: 17px; text-decoration: none; margin: 4px 2px; cursor: pointer;}");

		out.println("</style>");
		out.println("<title>Shopping Cart</title>");
		out.println("<a href=\"/MOBIUS4/index.jsp\" class = \"button\">Back to Store</a></button>");
		out.println("<body>");
		out.println("<h1>Thank you for your purchase.</h3>");
		//out.println("Time: " + (new Date()).toLocaleString());
		
		ShoppingBasket myLittleWarList; // Create a reference to the Shopping Basket
		HttpSession session = request.getSession(); //
		myLittleWarList = (ShoppingBasket) session.getAttribute("warlist"); // get the shopping cart items from server
		if (myLittleWarList == null) { // I haven't buy any plane
			myLittleWarList = new ShoppingBasket(); // create a new warlist from the class Shopping Basket
			session.setAttribute("warlist", myLittleWarList);
		}
		
		// String product = "A10 Warthog";
		// Integer cost = 10000000;
		String product = request.getParameter("product");
		Integer cost = Integer.parseInt(request.getParameter("cost"));
		
		//myLittleWarList.adding(product, cost); // add to the hashmap (dict in Python)
		session.setAttribute("warlist", myLittleWarList); // update the hashmap to the server
		
		/*
		String product2 = "F22 Lightning";
		Integer cost2 = 50000000;
		myLittleWarList.adding(product2, cost2); // add to the hashmap (dict in Python)
		session.setAttribute("warlist", myLittleWarList); // update the hashmap to the server
		*/
		
		out.println("<h3>You have added to your shopping cart:</h2>");
		
		ShoppingBasket myOrderList;
		myOrderList = (ShoppingBasket) session.getAttribute("warlist"); // obtain the items from the shopping cart
		HashMap<String, Integer> items = myOrderList.getBasket(); // create a hashmap to keep the shopping list from server
		int totalInvoice = 0;
		for (String key: items.keySet()){
			out.println("<b>" + key + ": $" + items.get(key) + "<br>");
			totalInvoice = totalInvoice + items.get(key); // adding up the cost
		}
		out.println("<br>");
		out.println("Your current total is: $" + totalInvoice + "</b>");
		
		out.println("<br><br><a href=\"/MOBIUS4/CheckOutPage\" class = \"button2\">Continue to Checkout</a></button>");

		
		out.println("</body>");
		out.println("</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
