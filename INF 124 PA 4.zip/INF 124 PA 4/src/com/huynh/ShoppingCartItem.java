package com.huynh;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;
@JsonAutoDetect(fieldVisibility=JsonAutoDetect.Visibility.ANY, getterVisibility=JsonAutoDetect.Visibility.NONE, 
setterVisibility=JsonAutoDetect.Visibility.NONE, creatorVisibility=JsonAutoDetect.Visibility.NONE)

public class ShoppingCartItem
{
	@JsonProperty("itemID")
	int itemID = 0;
	@JsonProperty("name")
	String name = "";
	@JsonProperty("quantity")
	int quantity = 0;
	@JsonProperty("subtotal")
	int subtotal = 0;

	
	public int get_itemID(){
		return itemID;
	}
	
	public String get_name(){
		return name;
	}
	
	public int get_quantity(){
		return quantity;
	}
	
	
	public int get_subtotal(){
		return subtotal;
	}
	
	public void set_itemID(int id){
		this.itemID = id;
	}
	
	public void set_name(String name){
		this.name = name;
	}
	
	public void set_quantity(int quantity){
		this.quantity = quantity;
	}
	
	
	public void set_subTotal(int subtotal){
		this.subtotal = subtotal;
	}
	
}
