package com.huynh;

import java.io.IOException;


import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Servlet implementation class Su34
 */
@WebServlet("/Su34")
public class Su34 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Su34() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
    	String requestURI = request.getRequestURI();
    	String myPlane = "Su-34";
    	System.out.println(myPlane);
    
		String contextPath = request.getContextPath();
		String hostname = request.getServerName();
		int port = request.getServerPort();
		response.setContentType("text/html;charset=UTF-8");	
		PrintWriter out = response.getWriter();
		
		// Call the web service to query the SQL database for the plane information
		GetPlaneData getPlaneData = new GetPlaneData();
		String webServiceURL = "http://" + hostname + ":" + Integer.toString(port) + contextPath + "/rest/Hello/" + myPlane;
		Plane plane = new Plane();
		plane = getPlaneData.webserviceCall(webServiceURL);
		
		String name = plane.name;
    	String designation = plane.designation;
    	String price = plane.price;
    	String role = plane.role;
    	String manufacturer = plane.manufacturer;
    	String origin = plane.origin;
    	String crew = plane.crew;
    	String length = plane.length;
    	String wingspan = plane.wingspan;
    	String max_speed = plane.max_speed;
    	String armament = plane.armament;
    	String paragraph_1 = plane.paragraph_1;
    	String paragraph_2 = plane.paragraph_2;
    	int true_price = plane.true_price;
    	
		out.println("<!DOCTYPE html><html><head><meta charset=\"UTF-8\">");
		out.println("<title>" + designation + " " + '"' + name + '"' + "</title>");
		out.println("</head><style>h1 {	text-align: center;	float: center;	margin: 0;}.button {	background-color: #008CBA;    border: none;    color: white;    float: left;    padding: 15px 32px;    text-align: left;    text-decoration: none;    font-size: 17px;    margin: 4px 2px;    cursor: pointer;}</style>");
		out.println("<body>	<a href=\"NewFile1.jsp\" class = \"button\">Back to Store</a></button>");
		out.println("<h1 style=\"font-size:300%;text-align:center;\">" + designation + " \"" + name + "\"</h1>");
		out.println("<p style=\"font-size:200%;text-align:left;\"> <img src='" + designation + ".jpg'" +  " alt='" + designation + "' style='float:right;margin:0px 100px;width:615.2px;height:460.4px;'>");
		out.println("Name: " + designation + " \"" + name + "\"<br>");
		out.println("Role: " + role + "<br>");
		out.println("Manufacturer: " + manufacturer + "<br>");
		out.println("National Origin: " + origin + "<br>");
		out.println("Unit Cost: " + price + "<br>");
		out.println("<br>");
		out.println("<strong>General Characteristics</strong><br>");
		out.println("Crew: " + crew + "<br>");
		out.println("Length: " + length + " meters<br>");
		out.println("Wingspan: " + wingspan + " meters<br>");
		out.println("Maximum Speed: Mach " + max_speed + "<br>");
		out.println("<br>");
		out.println("</p>");
		out.println("<p style=\"font-size:150%;\">");
		out.println("<br>");
		out.println(paragraph_1);
		out.println("<br><br>");
		out.println(paragraph_2);
		out.println("<br><br>");
		out.println("Armament: " + armament);
		out.println("</p>");
			
		out.println("<table border=\"1px\">");
		out.println("<form action='" + contextPath + "/rest/Hello' method='POST'>");
		out.println("<th>Plane Name</th> <th>Price</th> <th>Add to Cart</th>");
		out.println("<tr><td>" + designation + "</td> <td>$" + String.format("%,d",true_price) + "</td><td><input type=\"hidden\" name=\"product\" value=\"" + designation + "\">");
		out.println("<input type=\"hidden\" name=\"cost\" value=\"" + true_price + "\">");
		out.println("Quantity: <input type='number' name='quantity' value='1'>");
		out.println("<input type=\"submit\" value=\"Add to cart\"></td>");
		out.println("</tr>");
		out.println("</form>");
		
		out.println("</table>");
		out.println("<br><hr>");
		
		out.println("</body>");
		out.println("</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
