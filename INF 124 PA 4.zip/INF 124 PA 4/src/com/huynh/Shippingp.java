package com.huynh;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class Shippingp
 */
@WebServlet("/Shippingp")
public class Shippingp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Shippingp() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE html><html><head><meta charset=\"ISO-8859-1\"><title>Founders</title></head>"
				+ "<style>	.tabs {		list-style-type: none;		margin: 0;		padding: 0;		overflow: hidden;		background-color: #333;	}"
				+ ".tabs a {	float: left;  display: block;  color: #f2f2f2;  text-align: center;  padding: 14px 16px;  text-decoration: none;  font-size: 17px;  }"
				+ ".tabs a:hover {	background-color: #c4eFe9;	color: black;	}.tabs a.active {	background-color: #008CBA;	color: white;	}"
				+ "</style>"
				+ "<body>"
				+ "<h1 style=\"font-size: 36px; text-align:center;\">Project MOBIUS</h1><div class=\"tabs\">	"
				+ "<a href=\"/MOBIUS4/index.jsp\">For Sale</a>	<a href=\"Aboutp\">About</a>	<a href=\"Foundersp\">Founders</a>	"
				+ "<a class=\"active\" href=\"Shipping\">Payment/Shipping</a></div><h2><b>Placing an Order</b></h2>"
				+ "To place an order, simply fill out the form at the bottom of the product's detail page. After you place an order, a sales associate will "
				+ "contact you with an invoice of your order including shipping fees.<br><br><br><h2><b>Accepted Payment Method</b></h2>As of now, "
				+ "Project MOBIUS is only accepting credit card payment due to a recent influx of bounced checks and suitcases full of suspiciously acquired money. "
				+ "Payment must be made in full within seven days of the order invoice. Orders will be invoiced when all items in the order are ready to be shipped. "
				+ "All sales are final. No Refunds.<br><br><br><h2><b>Shipping Methods</b></h2>Delivery (Assembled): Aircraft will be loaded onto a C-5 Galaxy "
				+ "in pieces and delivered to an airport of your choosing. Upon arrival, aircraft will be assembled, fuelled, and armed by a team of "
				+ "trained engineers.<br><br>"
				+ "Delivery (Economy): Aircraft will be loaded onto a C-5 Galaxy in pieces and delivered to an airport of your choosing as a secure package.<br><br>"
				+ "Rebase (Concierge): Aircraft will be flown to an airport of your choosing by our highly trained pilots. Fuel used will not be compensated. "
				+ "Additional charges may be required if refuellings are necessary for delivery.<br><br>"
				+ "Rebase (Personal): Aircraft will be made available at a specified airport for you to fly to a location of your choosing. Aircraft will be fuelled "
				+ "and armed before takeoff.</body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
