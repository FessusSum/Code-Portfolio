package com.huynh;

import java.util.HashMap;

public class ShoppingBasket {
	HashMap<String, Integer> basket;
	
	public ShoppingBasket() {
		basket = new HashMap<>();
	}
	@SuppressWarnings("rawtypes")
	public HashMap getBasket(){
		return basket;
	}
	public boolean adding(String productID, int price, int quantity){
		int subtotal = quantity * price;
		basket.put(productID, subtotal);
		boolean status = true; // Do the SQL thing and return a status. True if the SQL thing works
		return status;
	}
}