package com.huynh;

import java.sql.*;

public class DBUtils {
	
	public static ResultSet returnQuery(Connection connection, final String sql){
		Statement statement = null;
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            return resultSet;

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return null;

    }
	
	public static String returnQuery2(Connection connection, final String sql){
		Statement statement = null;
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            return "AAAA";

        } catch (SQLException e) {
            return e.getMessage();
        }

    }
	
	
	
	public static boolean updateDB(Connection connection, final String sql){
		Statement statement = null;
        try {
            statement = connection.createStatement();
            statement.executeUpdate(sql);
            return true;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }

    }
	
	public static String updateDB2(Connection connection, final String sql){
		Statement statement = null;
        try {
            statement = connection.createStatement();
            statement.executeUpdate(sql);
            return "yes";
        } catch (SQLException e) {
            return e.getMessage();
        }

    }
}
