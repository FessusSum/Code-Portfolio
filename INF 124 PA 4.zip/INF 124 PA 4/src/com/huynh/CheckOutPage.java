package com.huynh;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class CheckOutPage
 */
@WebServlet("/CheckOutPage")
public class CheckOutPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckOutPage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<br>");
		String contextPath = request.getContextPath();
		
		// Retrieve the shopping cart
		/*
		HttpSession session = request.getSession();
		ShoppingBasket myOrderList;
		myOrderList = (ShoppingBasket) session.getAttribute("warlist"); // obtain the items from the shopping cart
		HashMap<String, Integer> items = myOrderList.getBasket(); // create a hashmap to keep the shopping list from server
		int totalInvoice = 0;
		for (String key: items.keySet()){
			out.println("<b>" + key + ": $" + items.get(key) + "<br>");
			totalInvoice = totalInvoice + items.get(key); // adding up the cost
		}
		*/
		int totalInvoice = Integer.parseInt(request.getParameter("totalcost"));
		String orderdetail = request.getParameter("orderdetail");
		
		out.println("<br><br>");
		out.println("Your current total is: $" + totalInvoice + "</b>");
		
		out.println("<html>");
		out.println("<head><title>CheckOut</title>");
		out.println("<meta charset=\"UTF-8\">");
		out.println("<meta name=\"viewport\" content=\"width=device-width\">");
		out.println("</head>");
		out.println("<body>");
		
		// Start Ordering Form Section
		out.println("<h1 align=center>Order Form</h1>" +
				"<form action='"+ contextPath + "/Confirmation' method='post'>" +
		"<h2 style=\"color:blue\">Orders from this email</h2>" +
		"<div id=\"email_order\"></div>" +
		"<br><hr>" + 
		"<b>First Name: </b>" +
		"<input type=\"text\" id=\"firstname\" name = \"fname\">" +
		"<p style=\"color:red\" id=\"alarmFN\"></p>" +
		"<br>" +
		"<b>Last Name: </b>" +
		"<input type=\"text\" id=\"lastname\" name = \"lname\">" +
		"<p style=\"color:red\" id=\"alarmLN\"></p>" +
		"<br>");
		
		out.println("<b>Email Address: </b><br>" +
		"<input type=\"text\" id=\"email\" name = \"email\">" +
		"<p style=\"color:red\" id=\"alarmEM\"></p><br>");
		
		out.println("<b>Phone Number (10 digit numbers only): </b>" +
		"<input type='tel' id=\"phone\" name = \"phone\">" +
		"<p style=\"color:red\" id=\"alarmPH\"></p><br>");
		
		out.println("<b>SHIPPING INFORMATION</b><br><br>" +
		"<b>Address: </b>" +
		"<input type='text' id=\"street\" name = \"address\" size=\"50\">" +
		"<p style=\"color:red\" id=\"alarmAD\"></p><br>" +
		"<b>Zip Code</b>" +
		"<input type='text' id=\"zipcode\" name = \"zip\" size = \"5\">" +
		"<p style=\"color:red\" id=\"alarmZIP\"></p><br>");
		
		out.println("<b>City: </b>" +
		"<input type='text' id=\"city\" name = \"city\" size = \"50\">" +
		"<p style=\"color:red\" id=\"alarmCT\"></p><br>" +
		"<b>State: </b>" +
		"<input type='text' id=\"state\" name = \"state\" size = \"20\">" +
		"<p style=\"color:red\" id=\"alarmST\"></p><br>");
		
		out.print("<b>Shipping Method: </b>" +
		"<select id=\"shipping\" name = \"ship\">" +
			"<option value=\"Delivery (Assembled)\">Delivery (Assembled)</option>" +
			"<option value=\"Delivery (Economy)\">Delivery (Economy)</option>" +
			"<option value=\"Rebase (Concierge)\">Rebase (Concierge)</option>" +
			"<option value=\"Rebase (Personal)\">Rebase (Personal)</option>" +
		"</select><br><br>");
		
		out.print("<b>CREDIT CARD INFORMATION</b><br><br>" +
		"<b>Card Type</b>" +
		"<select id=\"cardtype\" name = \"cardtype\">" +
			"<option value=\"Visa\">VISA</option>" +
			"<option value=\"MasterCard\">MasterCard</option>" +
			"<option value=\"Amex\">American Express</option>" +
			"<option value=\"Discover\">Discover</option>" +
		"</select><br><br>");
		
		out.print("<b>Card number (16 digits no spaces): </b>" +
		"<input type='text' id='cardnumber' name = \"card\" size = \"16\">" +
		"<p style=\"color:red\" id=\"alarmCC\"></p><br>" +
		"<input type='hidden' name='totalcost' value='" + totalInvoice + "'>" +
		"<input type='hidden' name='ordertail' value='" + orderdetail + "'>" +
		"<input type=\"submit\" value=\"Buy Now\"><br>" +
		"</form>");
		
		out.println("</table>");
		out.println("<br><hr>");

		out.println("</body>");
		out.println("</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
