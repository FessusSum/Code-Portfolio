package com.huynh;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;


/**
 * Servlet implementation class ShoppingCart
 */
@WebServlet("/ShoppingCart")
public class ShoppingCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShoppingCart() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		String contextPath = request.getContextPath();
		String hostname = request.getServerName();
		int port = request.getServerPort();
		String webServiceURL = "http://" + hostname + ":" + Integer.toString(port) + contextPath + "/rest/Hello";
		response.setContentType("text/html;charset=UTF-8");	
		PrintWriter out = response.getWriter();
		
		String method = request.getParameter("_method");
		if (method == "PUT") {
			out.println (method + "<br>");
		}
		
		out.println("<!DOCTYPE html><html><head><meta charset=\"ISO-8859-1\"><title>Shopping Cart</title></head><style>	"
				+ ".tabs {		list-style-type: none;		margin: 0;		padding: 0;		overflow: hidden;		background-color: #333;	}"
				+ ".tabs a {	float: left;  display: block; color: #f2f2f2;  text-align: center;  padding: 14px 16px;  text-decoration: none;  font-size: 17px;  }"
				+ ".tabs a:hover {	background-color: #c4eFe9;	color: black;	}"
				+ ".tabs a.active {	background-color: #008CBA;	color: white;	}"
				+ "</style>" +"<body><h1 style=\"font-size: 36px; text-align:center;\">Project MOBIUS</h1>"
				+ "<div class=\"tabs\">	<a href=\"/MOBIUS4/NewFile1.jsp\">For Sale</a>	<a href=\"About.jsp\">About</a>	"
				+ "<a href=\"Founders.jsp\">Founders</a>	<a href=\"Shipping.jsp\">Payment/Shipping</a><a class=\"active\" href=\"ShoppingCart\">Shopping Cart</a></div><h2><b>Shopping Cart</b></h2>");
		out.println("<body><br>");
		//out.println("Served at: " + contextPath + " from host " + hostname + ":" + Integer.toString(port) + "<br>");
		//out.println("web service URL: " + webServiceURL + "<br>");
		out.println("<style>");
		out.println(".resize { width: 145px; height: auto;}");
		out.println("</style>");
		//out.println("<i>Time: " + (new Date()) + "</i>");
		//out.println("<h2>Shopping Cart</h2>");

		
		// Call Web Service to get the content of the Shopping Cart
		JerseyWebServiceClient webservice = new JerseyWebServiceClient();
		// String cartItem = webservice.jsonGET("http://localhost:8080/FirstRestService/rest/Hello");
		String cartItem = webservice.jsonGET(webServiceURL);
		// out.println("JSON from Webservice: " + cartItem + "<br>");
		// Decode JSON into the object format
		ObjectMapper objectMapper = new ObjectMapper();
		List<ShoppingCartItem> shoppingCartItem = objectMapper.readValue(cartItem, new TypeReference<List<ShoppingCartItem>>(){});
		
		// Display the Shopping Cart
		out.println("<h3>Your cart has: " + shoppingCartItem.size() + " items</h3>");
		if (shoppingCartItem.size() == 0)
			out.println("There are no items in your cart<br>");
		else {
			out.println("<table><tr><th>Item ID</th><th>Item Name</th>");
			out.println("<th>Quantity</th> <th>Subtotal</th>");
			for (ShoppingCartItem item: shoppingCartItem) {
				out.println("<tr><td>" + item.get_itemID() + "</td>");
				out.println("<td>" + item.get_name() + "</td>");
				out.println("<td>" + item.get_quantity()+ "</td>");
				out.println("<td>$" + String.format("%,d", item.get_subtotal()) + "</td>");
				out.println("</tr>");
			}
			out.println("</table>");
		}
		out.println("<hr>");
		int cartTotal = 0;
		
		for (ShoppingCartItem item : shoppingCartItem) {
			cartTotal += item.get_subtotal();
		}
		
		// Display total and placing order
		out.println("<b>Total Amount: $" + String.format("%,d", cartTotal) + "</b><br><br>");
		String orderNow = "<form action='"+ contextPath + "/CheckOutPage' method='GET'>"
				+ "<input type='hidden' name='totalcost' value='" + cartTotal + "'>"
				+ "<input type='submit' value='PLACE ORDER'>"
				+ "</form><br>";
		out.println(orderNow);
		
		// Allowing update quantity
		String updateQuantity = "<h3>Change Purchase Quantity</h3>"
								+ "<form action='"+ contextPath + "/UpdateItem' method='GET'>"
								+ "Item ID: <input type='number' name='itemid' value=''>"
								+ "New quantity: <input type='number' name='quantity' value=''>"
								+ "<input type='hidden' name='_method' value='PUT'>" // HTML Form does not have PUT. Recommended by most frameworks
								+ "<input type='submit' value='Update Quantity'>"
								+ "</form><br>";
		out.println(updateQuantity);
		
		// Allowing deletion of one item
		out.println("<h3>Delete An Item</h3>");
		String deleteAnItem =   "<form action='"+ contextPath + "/UpdateItem' method='GET'>"
								+ "Item ID: <input type='number' name='itemid' value=''>"
								+ "<input type='hidden' name='_method' value='DELETE'>"
								+ "<input type='submit' value='Delete Item'>"
								+ "</form><br>";
		out.println(deleteAnItem);
		
		// Allow deletion of the entire cart
		out.println("<h3>Delete Cart</h3>");
		String deleteCart   =   "<form action='"+ contextPath + "/UpdateItem' method='GET'>"
								+ "<input type='hidden' name='_method' value='WIPE_CART'>"
								+ "<input type='submit' value='Delete Cart'>"
								+ "</form><br>";
		out.println(deleteCart);
			
		out.println("</body>");
		out.println("</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
