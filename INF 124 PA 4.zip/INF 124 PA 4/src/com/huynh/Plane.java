package com.huynh;

public class Plane {
	String designation="";
	String name="";
	String manufacturer="";
	String short_role="";
	String blurb="";
	String price="";
	String equip_1="";
	String equip_2="";
	String equip_3="";
	String equip_4="";
	String origin = "";
	String crew = "";
	String length = "";
	String wingspan = "";
	String max_speed="";
	String armament="";
	String paragraph_1="";
	String paragraph_2="";
	int true_price=0;
	String role = "";
	
	public String get_designation(){
		return designation;
	}
	
	public String get_name(){
		return name;
	}
	
	public String get_manufacturer(){
		return manufacturer;
	}
	
	public String get_short_role(){
		return short_role;
	}
	
	public String get_blurb(){
		return blurb;
	}
	
	public String get_price(){
		return price;
	}
	
	public String get_equip_1(){
		return equip_1;
	}
	
	public String get_equip_2(){
		return equip_2;
	}
	
	public String get_equip_3(){
		return equip_3;
	}
	
	public String get_equip_4(){
		return equip_4;
	}
	
	public String get_origin(){
		return origin;
	}
	
	public String get_crew(){
		return crew;
	}
	
	public String get_length(){
		return length;
	}
	
	public String get_wingspan(){
		return wingspan;
	}
	
	public String get_max_speed(){
		return max_speed;
	}
	
	public String get_armament(){
		return armament;
	}
	
	public String get_paragraph_1(){
		return paragraph_1;
	}
	
	public String get_paragraph_2(){
		return paragraph_2;
	}
	
	public int get_true_price(){
		return true_price;
	}
	
	public String get_role(){
		return role;
	}
	//Setters
	
	public void set_designation(String designation){
		this.designation = designation;
	}
	
	public void set_name(String name){
		this.name = name;
	}
	
	public void set_manufacturer(String manufacturer){
		this.manufacturer = manufacturer;
	}
	
	public void set_short_role(String short_role){
		this.short_role = short_role;
	}
	
	public void set_blurb(String x){
		this.blurb = x;
	}
	
	public void set_price(String x){
		this.price = x;
	}
	
	public void set_equip_1(String x){
		this.equip_1 = x;
	}
	
	public void set_equip_2(String x){
		this.equip_2 = x;
	}
	
	public void set_equip_3(String x){
		this.equip_3 = x;
	}
	
	public void set_equip_4(String x){
		this.equip_4 = x;
	}
	
	public void set_origin(String x){
		this.origin = x;
	}
	
	public void set_crew(String x){
		this.crew = x;
	}
	
	public void set_length(String x){
		this.length = x;
	}
	
	public void set_wingspan(String x){
		this.wingspan = x;
	}
	
	public void set_max_speed(String x){
		this.max_speed = x;
	}
	
	public void set_armament(String x){
		this.armament = x;
	}
	
	public void set_paragraph_1(String x){
		this.paragraph_1 = x;
	}
	
	public void set_paragraph_2(String x){
		this.paragraph_2 = x;
	}
	
	public void set_true_price(int x){
		this.true_price = x;
	}
	
	public void set_role(String x){
		this.role = x;
	}
}
