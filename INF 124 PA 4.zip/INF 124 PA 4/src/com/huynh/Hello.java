package com.huynh;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

@Path("/Hello") // This path will be tag on to the Context Path/servlet-mapping URL/hello
public class Hello {
	// Called if TEXT_PLAIN is request
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public Response sayPlainTextHello() {
		String subspace = "We are the Borg.  Lower your shields and surrender your ships. Resistance is futile!";
		return Response.ok().entity(subspace).build();
	}
	
	@Path("/{id}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getPlaneInfo(@PathParam("id") String id) {
		// String message = "This is the plane";
		// return Response.ok().entity(message).build();
	
		Plane plane = new Plane();
		if (id == null){
			return Response.status(Response.Status.NOT_FOUND).build();
		}
		SQLBuilder sqlBuilder = new SQLBuilder();
		plane = sqlBuilder.getPlane(id);
		ObjectMapper objectMapper = new ObjectMapper();
		String jsonValue;
		try
		{
			jsonValue = objectMapper.writeValueAsString(plane);
			return Response.ok(jsonValue).build();
		}
		catch (JsonGenerationException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (JsonMappingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return Response.status(Response.Status.NOT_FOUND).build();
		
	}
	
	
	@DELETE
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces(MediaType.TEXT_HTML)
	public String deleteItem(String inputJSON) {
		SQLBuilder sqlBuilder = new SQLBuilder();
		ObjectMapper objectMapper = new ObjectMapper();
		ShoppingCartItem item = new ShoppingCartItem();
		try
		{
			System.out.println(inputJSON);
			item = objectMapper.readValue(inputJSON, ShoppingCartItem.class);
			boolean status = false;
			if (item.itemID >= 0){
				status = sqlBuilder.SingleDelete(item);
				System.out.println("Item: " + item.itemID + " has been deleted.");
			}
			else {
				status = sqlBuilder.MassDelete(item);
				System.out.println("All items have been deleted.");
			}
			
			if (status) {
				String alertMsg = "Deletion has been completed.";
				String message = "<html><script type='text/javascript'>"
						+ "alert('" + alertMsg + "');"
						+ "location='/MOBIUS4/ShoppingCart';</script>";
				return message;
			}
		}
		catch (JsonParseException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (JsonMappingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "Hello WS: INTERNAL_SERVER_ERROR";
	}
	
	@PUT
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces(MediaType.TEXT_HTML)
	public String updateItem(String inputJSON) { // JSON coming in from input Stream
		SQLBuilder sqlBuilder = new SQLBuilder();
		ObjectMapper objectMapper = new ObjectMapper();
		try
		{
			ShoppingCartItem item = objectMapper.readValue(inputJSON, ShoppingCartItem.class);
			boolean status = sqlBuilder.SingleUpdate(item, item.get_quantity());
			if (status) {
				String alertMsg = "The request update has been made.";
				System.out.println(alertMsg);
				String message = "<html><script type='text/javascript'>"
						+ "alert('" + alertMsg + "');"
						+ "location='/MOBIUS4/ShoppingCart';</script>";
				return message;
			}
		}
		catch (JsonParseException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (JsonMappingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Hello WS: INTERNAL_SERVER_ERROR";
	}
		
	@POST
	@Path("/order")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_HTML)
	public String saveOrderInfo(String inputJSON) {
		SQLBuilder sqlBuilder = new SQLBuilder();
		ObjectMapper objectMapper = new ObjectMapper();
		Customer customer = new Customer();
		try
		{
			customer = objectMapper.readValue(inputJSON, Customer.class);
			System.out.println("Hi there");
			boolean status = sqlBuilder.InsertCustomer(customer);
			if (status) {
				String alertMsg = "Thank you for placing an order with us."
					+ " Don't get killed. I need your business.";
				String message = "<html><script type='text/javascript'>"
						+ "alert('" + alertMsg + "');"
						+ "location='/MOBIUS4/NewFile1.jsp';</script>";
				return message;
			}
		}
		catch (JsonParseException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (JsonMappingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "INTERNAL_SERVER_ERROR";
	}
	
	
	@POST
	@Consumes({MediaType.APPLICATION_FORM_URLENCODED})
	@Produces(MediaType.TEXT_HTML)
	public String addToCart(@FormParam("product") String planeDesignation, @FormParam("cost") String cost,
			@FormParam("quantity") int quantity) {
		System.out.println(planeDesignation + "," + cost + "," + quantity);
		
		if (planeDesignation == null)
			return "You need to select a plane";
		if (cost == null)
			return "Do you think these state-of-the-art planes are free?";
		if (quantity == 0) {
			String message = "<html><script type='text/javascript'>"
							+ "alert('Buy a plane already!');"
							+ "location='/MOBIUS4/" + planeDesignation + ".jsp';</script>";
			return message;
		}
		
		if (planeDesignation != null && cost != null && quantity != 0) {
			ShoppingCartItem item = new ShoppingCartItem();
			int truecost = Integer.parseInt(cost);
			item.set_name(planeDesignation);
			item.set_quantity(quantity);
			item.set_subTotal(quantity * truecost);
			
			SQLBuilder sqlBuilder = new SQLBuilder();
			boolean status = sqlBuilder.SingleInsert(item);
			
			if (status) {
				String alertMsg = "Thank you. Your order of "+ Integer.toString(quantity) + " " + planeDesignation + " has been added to Shopping Cart."
					+ " See your Shopping Cart in the main page.";
				String message = "<html><script type='text/javascript'>"
						+ "alert('" + alertMsg + "');"
						+ "location='/MOBIUS4/ShoppingCart';</script>";
				return message;
			}
		}
		return "INTERNAL_SERVER_ERROR";
	}
	
	// Called if APPLICATION/JSON is requested
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getShoppingCart() {
		SQLBuilder sqlBuilder = new SQLBuilder();
		List<ShoppingCartItem> myWarList = new ArrayList<ShoppingCartItem>();
		String myWarListJSON = "{}";
		myWarList = sqlBuilder.getAll(); // obtain the complete shopping cart from the SQL
		
		// Convert myWarList to JSON
		ObjectMapper mapper = new ObjectMapper();
		try
		{
			myWarListJSON = mapper.writeValueAsString(myWarList);
		}
		catch (JsonGenerationException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (JsonMappingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return Response.ok().entity(myWarListJSON).build();
	}
	
	// Called if XML is requested
	@GET
	@Produces(MediaType.TEXT_XML)
	public String sayXMLHello() {
		return "<?xml version=\"1.0\"?>" + "<hello> Hello World! We are the Borg." + "</hello>";
	}
	
	// Called if HTML is requested
	@GET
	@Produces(MediaType.TEXT_HTML)
	public String sayHtmlHello() {
		return "<HTML> " + "<TITLE>" + "Hello, World!" + "</TITLE>"
				+ "<body><h3>" + "Hello, World! We are the Borg. Lower your shields and surrender your ships" + "</body></h3>" + "</html>";
	}

}
