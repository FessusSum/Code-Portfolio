package com.huynh;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UpdateItem
 */
@WebServlet("/UpdateItem")
public class UpdateItem extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateItem() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String contextPath = request.getContextPath();
		String hostname = request.getServerName();
		int port = request.getServerPort();
		String webServiceURL = "http://" + hostname + ":" + Integer.toString(port) + contextPath + "/rest/Hello";
		response.setContentType("text/html;charset=UTF-8");	
		PrintWriter out = response.getWriter();
		
		// PUT method is used for updating the quantity of the item and its subtotal. First, extract the updated information from the HTTP Request
		String method = request.getParameter("_method");
		int itemID = -1;
		if (!method.contains("WIPE_CART"))
			itemID = Integer.parseInt(request.getParameter("itemid"));
		
		// Second, check to make sure that it is a PUT method.
		if (method.contains("PUT")) {
			out.println ("<h1>" + method + "</h1>");
			int newQuantity = Integer.parseInt(request.getParameter("quantity"));
			ShoppingCartItem item = new ShoppingCartItem();
			SQLBuilder sqlBuilder = new SQLBuilder();
			item = sqlBuilder.getOneItem(itemID); // Third, obtain the item from the database
			int newSubtotal = (int)(((float)item.get_subtotal() / item.get_quantity()) * (float)newQuantity); // Fourth, calculate the new subtotal
			
			
			//Finally, convert it JSON and give it to the web service
			String jsonValue = "{\"itemID\": " + itemID + ", \"name\": \"" + item.name + 
					"\", \"quantity\": " + newQuantity + ", \"subtotal\": " + newSubtotal + "}";
			JerseyWebServiceClient webservice = new JerseyWebServiceClient();
			out.println(jsonValue);
			webservice.jsonPUT(webServiceURL, jsonValue);
		}
		else if (method.contains("DELETE")) {
			out.println("<h1>" + method + "</h1>");
			ShoppingCartItem item = new ShoppingCartItem();
			SQLBuilder sqlBuilder = new SQLBuilder();
			item.set_itemID(itemID);
			String jsonValue = "{\"itemID\": " + itemID + ", \"name\": \"Name" + item.name + 
					"\", \"quantity\": " + item.quantity + ", \"subtotal\": " + item.subtotal + "}";
			JerseyWebServiceClient webservice = new JerseyWebServiceClient();
			out.println(jsonValue);
			webservice.jsonDEL(webServiceURL, jsonValue);
		}
		else if (method.contains("WIPE_CART")) {
			out.println("<h1>" + method + "</h1>");
			ShoppingCartItem item = new ShoppingCartItem();
			SQLBuilder sqlBuilder = new SQLBuilder();
			item.set_itemID(itemID);
			String jsonValue = "{\"itemID\": " + itemID + ", \"name\": \"Gonner" + item.name + 
					"\", \"quantity\": " + item.quantity + ", \"subtotal\": " + item.subtotal + "}";
			JerseyWebServiceClient webservice = new JerseyWebServiceClient();
			out.println(jsonValue);
			webservice.jsonDEL(webServiceURL, jsonValue);
		}
			
			response.sendRedirect(request.getHeader("referer"));
	}

	/*
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
