package com.huynh;
import com.huynh.DBConnector;

import com.huynh.DBUtils;
import com.huynh.ShoppingCartItem;
import com.huynh.Plane;
import com.huynh.Customer;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SQLBuilder {
	
	public String created(){
		return "Created Successfully";
	}
	//GET ALL
	public List<ShoppingCartItem> getAll(){
		List<ShoppingCartItem> basket = new ArrayList<ShoppingCartItem>();
		String sql = "SELECT * FROM `Order`";
		
		Connection connection = DBConnector.getConnection();
		ResultSet resultSet = DBUtils.returnQuery(connection, sql); 
		if (resultSet != null) {
            try {
                while (resultSet.next()) {
                    ShoppingCartItem item = new ShoppingCartItem();
                    item.set_name(resultSet.getString("product"));
                    item.set_subTotal(resultSet.getInt("price"));
                    item.set_itemID(resultSet.getInt("order_id"));
                    item.set_quantity(resultSet.getInt("quantity"));

                    basket.add(item);

                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return basket;
    }

	//Get One Item
	public ShoppingCartItem getOneItem(int itemID) {
		String sql = "SELECT * FROM `Order` WHERE `order_id`=" + itemID;
		Connection connection = DBConnector.getConnection();
		ResultSet resultSet = DBUtils.returnQuery(connection, sql); 
		if (resultSet != null) {
            try {
                while (resultSet.next()) {
                    ShoppingCartItem item = new ShoppingCartItem();
                    item.set_name(resultSet.getString("product"));
                    item.set_subTotal(resultSet.getInt("price"));
                    item.set_itemID(resultSet.getInt("order_id"));
                    item.set_quantity(resultSet.getInt("quantity"));
                    return item;

                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } 
		return null;
	}
	//Single Insert Order
  	public boolean SingleInsert(ShoppingCartItem item) {

        String sql = "INSERT INTO `Order` (`product`, `price`, `order_id`, `quantity`) VALUES ('" + item.get_name() + "', '" + item.get_subtotal() + "', NULL, '" + item.get_quantity() + "')";
  		//String sql = "INSERT INTO `Order` (`product`, `price`, `order_id`, `quantity`) VALUES ('stuff', '350', NULL, '5');";
        Connection connection = DBConnector.getConnection();
        return DBUtils.updateDB(connection, sql);

  	}
  	
	public String SingleInsert2(ShoppingCartItem item) {

        //String sql = "INSERT INTO `Order` (`product`, `price`, `order_id`, `quantity`) VALUES ('" + item.get_name() + "', '" + item.get_subtotal() + "', NULL, '" + item.get_quantity() + "')";
  		String sql = "INSERT INTO `Order` (`product`, `price`, `order_id`, `quantity`) VALUES ('stuff', '350', NULL, '5');";
        Connection connection = DBConnector.getConnection();
        return DBUtils.updateDB2(connection, sql);

  	}
  	
  	//Single Insert Customer
  	public boolean InsertCustomer(Customer customer) {

        String sql = "INSERT INTO `inf124-db-037`.`Customers` (`First_Name`, `Last_Name`, `Email`, `Phone`, `Address`, `Zip`, `City`, `State`, `Shipping_Method`, `Card_Type`, `Card_Num`, `Customer_ID`, `Order_Details`, `Final_Total`) VALUES ('" + 
        		customer.getFirst_name() + "', '"+ customer.getLast_name() + "', '" + customer.getEmail() + "', '" + customer.getPhone() + 
        		"', '" + customer.getAddress() + "', '" + customer.getZip() + "', '" + customer.getCity() + "', '" + customer.getState() + "', '" + customer.getShip() + 
        		"', '" + customer.getCard_type() + "', '" + customer.getCard_num() + "', NULL, '" + customer.getOrder_details() + "', '" + customer.getFinal_total() + "');";
        Connection connection = DBConnector.getConnection();
        return DBUtils.updateDB(connection, sql);

  	}
  	
  	//Single Update
  	public boolean SingleUpdate(ShoppingCartItem item, int new_total) {

        String sql = "UPDATE `Order` SET `quantity`=" + new_total + " WHERE `order_id`=" + item.get_itemID();
        Connection connection = DBConnector.getConnection();
        return DBUtils.updateDB(connection, sql);

  	}
  	
  	public String SingleUpdate2(ShoppingCartItem item, int new_total) {

        String sql = "UPDATE `Order` SET `quantity`=" + new_total + " WHERE `order_id`=" + item.get_itemID();
        Connection connection = DBConnector.getConnection();
        return DBUtils.updateDB2(connection, sql);

  	}
  	
  	//Single Delete
  	public boolean SingleDelete(ShoppingCartItem item) {

        String sql = "DELETE FROM `Order` WHERE `order_id`=" + item.get_itemID();
        Connection connection = DBConnector.getConnection();
        return DBUtils.updateDB(connection, sql);
  	}
 
  	//Mass Delete
  	public boolean MassDelete(ShoppingCartItem item) {

        String sql = "DELETE FROM `Order`";
        Connection connection = DBConnector.getConnection();
        return DBUtils.updateDB(connection, sql);
  	}
  	
  	//Read Single Plane
  	public Plane getPlane(String designation){
  		Plane plane = new Plane();
  		String sql = "";
  		sql = "SELECT * FROM `Planes` WHERE Designation = '"+ designation + "'";
  		Connection connection = DBConnector.getConnection();
		ResultSet resultSet = DBUtils.returnQuery(connection, sql); 
		
		if (resultSet != null) {
            try {
                while (resultSet.next()) {
                	plane.set_designation(resultSet.getString("Designation"));
                	plane.set_price(resultSet.getString("Price"));
                	plane.set_role(resultSet.getString("Role"));
                	plane.set_name(resultSet.getString("Name"));
                	plane.set_manufacturer(resultSet.getString("Manufacturer"));
                	plane.set_origin(resultSet.getString("Origin"));
                	plane.set_crew(resultSet.getString("Crew"));
                	plane.set_length(resultSet.getString("Length"));
                	plane.set_wingspan(resultSet.getString("Wingspan"));
                	plane.set_max_speed(resultSet.getString("Max_Speed"));
                	plane.set_armament(resultSet.getString("Armament"));
                	plane.set_paragraph_1(resultSet.getString("Paragraph_1"));
                	plane.set_paragraph_2(resultSet.getString("Paragraph_2"));
                	plane.set_short_role(resultSet.getString("Short_Role"));
                	plane.set_blurb(resultSet.getString("Blurb"));
                	plane.set_equip_1(resultSet.getString("Equip_1"));
                	plane.set_equip_2(resultSet.getString("Equip_2"));
                	plane.set_equip_3(resultSet.getString("Equip_3"));
                	plane.set_equip_4(resultSet.getString("Equip_4"));
                	plane.set_true_price(resultSet.getInt("True_Price"));


                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return plane;
    }
	
  	
}