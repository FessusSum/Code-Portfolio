package com.huynh;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.codehaus.jackson.map.ObjectMapper;

/**
 * Servlet implementation class Confirmation
 */
@WebServlet("/Confirmation")
public class Confirmation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Confirmation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<br>");
		
		String contextPath = request.getContextPath();
		String hostname = request.getServerName();
		int port = request.getServerPort();
		String webServiceURL = "http://" + hostname + ":" + Integer.toString(port) + contextPath + "/rest/Hello";
		
		// Read from the purchase order form
		String firstName = request.getParameter("fname");
		String lastName = request.getParameter("lname");
		String emailAddr = request.getParameter("email");
		String phoneNo = request.getParameter("phone");
		String streetAddr = request.getParameter("address");
		String zipCode = request.getParameter("zip");
		String city = request.getParameter("city");
		String state = request.getParameter("state");
		String shipCategory = request.getParameter("ship");
		String creditCard = request.getParameter("cardtype");
		String cardNo = request.getParameter("card");
		
		out.println("<html>");
		out.println("<head>");
		out.println("</head>");
		out.print("<style>");
		out.println(".button{background-color: #008CBA; border: none; color: white; float: left; padding: 15px 32px; font-size: 17px; text-decoration: none; margin: 4px 2px; cursor: pointer;}");

		out.println("</style>");
		out.println("<title>Shopping Cart</title>");
		
		// Form Validation
		boolean errorFlag = false;
		if (firstName == ""){
			out.println("<h2>Alert: Missing <u>First Name</u>. Click BACK and fix. </h2>");
			errorFlag = true;
		}
		if (lastName == ""){
			out.println("<h2>Alert: Missing <u>Last Name</u>. Click BACK and fix. </h2>");
			errorFlag = true;
		}
		if (emailAddr == ""){
			out.println("<h2>Alert: Missing <u>Email Address</u>. Click BACK and fix. </h2>");
			errorFlag = true;
		}
		if (phoneNo == ""){
			out.println("<h2>Alert: Missing <u>Phone Number</u>. Click BACK and fix. </h2>");
			errorFlag = true;
		}
		if (streetAddr == ""){
			out.println("<h2>Alert: Missing <u>Street Address</u>. Click BACK and fix. </h2>");
			errorFlag = true;
		}
		if (zipCode == ""){
			out.println("<h2>Alert: Missing <u>Zip Code</u>. Click BACK and fix. </h2>");
			errorFlag = true;
		}
		if (city == ""){
			out.println("<h2>Alert: Missing <u>City</u>. Click BACK and fix. </h2>");
			errorFlag = true;
		}
		if (state == ""){
			out.println("<h2>Alert: Missing <u>State</u>. Click BACK and fix. </h2>");
			errorFlag = true;
		}
		if (cardNo == ""){
			out.println("<h2>Alert: Missing <u>Credit Card Number</u>. Click BACK and fix. </h2>");
			errorFlag = true;
		}
		
		// Print out form information
		out.println("First Name: " + firstName + "<br>");
		out.println("Last Name: " + lastName + "<br>");
		out.println("Email: " + emailAddr + "<br>");
		out.println("Phone: " + phoneNo + "<br>");
		out.println("Street: " + streetAddr + "<br>");
		out.println("Zip Code: " + zipCode + "<br>");
		out.println("City: " + city + "<br>");
		out.println("State: " + state + "<br>");
		out.println("Shipping Type: " + shipCategory + "<br>");
		out.println("Credit Card use: " + creditCard + "<br>");
		out.println("Card Number: " + cardNo + "<br>");
		out.println("<hr>");
		
		
		// Retrieve the shopping cart
		int totalInvoice = Integer.parseInt(request.getParameter("totalcost"));
		String orderdetail = request.getParameter("orderdetail");
		
		// Create an Order Record and call the web service
		Customer customer = new Customer();
		customer.setFirst_name(firstName);
		customer.setLast_name(lastName);
		customer.setEmail(emailAddr);
		customer.setPhone(phoneNo);
		customer.setAddress(streetAddr);
		customer.setPhone(phoneNo);
		customer.setZip(zipCode);
		customer.setCity(city);
		customer.setState(state);
		customer.setShip(shipCategory);
		customer.setCard_type(creditCard);
		customer.setCard_num(cardNo);
		customer.setOrder_details(orderdetail);
		customer.setFinal_total(totalInvoice);

		out.println("<br><br>");
		out.println("Your current total is: $" + String.format("%,d",totalInvoice) + "</b>");
		
		
		if (!errorFlag){
			
			// Clean out cart
			ShoppingCartItem item = new ShoppingCartItem();
			SQLBuilder sqlBuilder = new SQLBuilder();
			int itemID = -1;
			item.set_itemID(itemID);
			String jsonValue = "{\"itemID\": " + itemID + ", \"name\": \"Gonner" + item.name + 
					"\", \"quantity\": " + item.quantity + ", \"subtotal\": " + item.subtotal + "}";
			JerseyWebServiceClient webservice = new JerseyWebServiceClient();
			webservice.jsonDEL(webServiceURL, jsonValue);
				
			out.println("<br><br><a href=\"" + contextPath + "/NewFile1.jsp\" class = \"button\">Back to Store</a></button>");
			out.println("</body>");
			out.println("</html>");
			
			// Call Web Service to transmit the order to the SQL
			webServiceURL = "http://" + hostname + ":" + Integer.toString(port) + contextPath + "/rest/Hello/order";
			webservice.jsonPOSTcustomer(webServiceURL, customer);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
