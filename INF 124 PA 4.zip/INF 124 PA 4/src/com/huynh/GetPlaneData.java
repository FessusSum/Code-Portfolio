package com.huynh;

import java.io.IOException;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public class GetPlaneData
{
	public Plane webserviceCall(String webServiceURL) throws JsonParseException, JsonMappingException, IOException {
		JerseyWebServiceClient webservice = new JerseyWebServiceClient();
		String jsonValue = webservice.jsonGET(webServiceURL); // Call the web service to get the plane information in JSON format
		
		ObjectMapper objectMapper = new ObjectMapper();
		Plane plane = objectMapper.readValue(jsonValue, Plane.class); // Convert the JSON into the Plane object
		return plane;
	}
}
